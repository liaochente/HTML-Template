Cufon.replace('#menu li a, #menu_active, h1, h2', { fontFamily: 'Myriad Pro', hover:true });
Cufon.replace('.text1', { fontFamily: 'Myriad Pro', hover:true, textShadow:'#afbfcf 1px 1px' });
Cufon.replace('.text1 span', { fontFamily: 'Myriad Pro', hover:true, textShadow:'#889ca8 1px 1px' });

