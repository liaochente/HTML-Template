## Emoji finder [![Travis CI](https://travis-ci.org/muan/emoji.svg?branch=gh-pages)](https://travis-ci.org/muan/emoji)

:heart: me some emoji. Go to http://emoji.muan.co/

![emoji](https://f.cloud.github.com/assets/1153134/1609791/b29e53ea-5559-11e3-8697-aee235cd9338.gif)

:octopus: :zap: :cat: = :octocat:<br />
Find the emoji that echoes your heart using keywords

:raised_hands::gun::moneybag::police_car::boom::hospital::syringe::skull:<br />
Tell a story

:oden::spaghetti::cookie::stew::ice_cream::icecream::sushi::curry::custard::dango::pizza::ramen::fried_shrimp::fries::chocolate_bar::hamburger:<br />
View emoji in groups and food-attack hungry people

#### Please contribute :pray:

There are almost 900 emoji, more keywords let you find emoji more easily. Go to [`emojis.json`](https://github.com/muan/emoji/blob/gh-pages/emojis.json) for the list of emoji & keywords.
